import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Home, Book, User, BookOpen, Star, LogIn, LogOut, PlusCircle, Menu
} from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../redux/authSlice';
import toast from 'react-hot-toast';

const Navigation = ({ children }) => {
  const location = useLocation();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { token, isAdmin } = useSelector((state) => state.auth);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const navigationItems = [
    { name: 'Home', path: '/', icon: Home, isVisible: true },
    { name: 'Books', path: '/books', icon: BookOpen, isVisible: true },
    { name: 'Profile', path: '/profile', icon: User, isVisible: !!token },
    { name: 'Add Book', path: '/add-book', icon: PlusCircle, isVisible: token && isAdmin },
    { name: 'Login', path: '/login', icon: LogIn, isVisible: !token },
    { name: 'Signup', path: '/signup', icon: Star, isVisible: !token }
  ];

  const handleLogout = () => {
    dispatch(logout());
    navigate('/login');
    toast.success('Logged out successfully');
    setIsSidebarOpen(false);
  };

  const toggleSidebar = () => setIsSidebarOpen(prev => !prev);

  return (
    <div className="flex min-h-screen relative">
      {/* Hamburger Button - visible on all screen sizes */}
      <button
        onClick={toggleSidebar}
        className="fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow"
      >
        <Menu className="w-6 h-6 text-indigo-600" />
      </button>

      {/* Sidebar - toggleable on all screen sizes */}
      <div
        className={`
          fixed z-40 top-0 left-0 h-full w-64 bg-white border-r shadow transform transition-transform duration-300 ease-in-out
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        <div className="p-6 border-b flex items-center justify-between">
          <div className="flex items-center">
            <Book className="w-8 h-8 text-indigo-600 mr-2" />
            <span className="text-xl font-bold text-indigo-600">BookReview</span>
          </div>
          {/* Close button */}
          <button onClick={toggleSidebar} className="text-gray-500 text-xl font-bold">×</button>
        </div>

        <nav className="p-4">
          <ul className="space-y-2">
            {navigationItems.filter(item => item.isVisible).map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  onClick={() => setIsSidebarOpen(false)}
                  className={`flex items-center p-3 rounded-lg transition-all ${
                    location.pathname === item.path
                      ? 'bg-indigo-50 text-indigo-600'
                      : 'hover:bg-indigo-50 text-gray-600 hover:text-indigo-600'
                  }`}
                >
                  <item.icon className="w-5 h-5 mr-3" />
                  {item.name}
                </Link>
              </li>
            ))}
            {token && (
              <li>
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center p-3 rounded-lg text-red-600 hover:bg-red-50 transition-all"
                >
                  <LogOut className="w-5 h-5 mr-3" />
                  Logout
                </button>
              </li>
            )}
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <main className="flex-grow w-full transition-all duration-300 pt-16">
        {children}
      </main>

      {/* Bottom Mobile Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t md:hidden z-50">
        <div className="grid grid-cols-5 py-2">
          {navigationItems.filter(item => item.isVisible).map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center justify-center py-2 transition-all ${
                location.pathname === item.path
                  ? 'text-indigo-600'
                  : 'text-gray-500 hover:text-indigo-600'
              }`}
            >
              <item.icon className="w-6 h-6" />
              <span className="text-xs mt-1">{item.name}</span>
            </Link>
          ))}
          {token && (
            <button
              onClick={handleLogout}
              className="flex flex-col items-center justify-center py-2 text-red-500 hover:text-red-600"
            >
              <LogOut className="w-6 h-6" />
              <span className="text-xs mt-1">Logout</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Navigation;

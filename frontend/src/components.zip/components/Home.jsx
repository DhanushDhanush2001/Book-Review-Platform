import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getBooks } from '../redux/booksSlice';
import BookCard from '../components/BookCard';
import { Link } from 'react-router-dom';

const Home = () => {
  const dispatch = useDispatch();
  const { books, loading } = useSelector((state) => {
    const rawBooks = state.books.books;
    const parsedBooks = Array.isArray(rawBooks)
      ? rawBooks
      : rawBooks?.data || [];
    return {
      books: parsedBooks,
      loading: state.books.loading,
    };
  });

  useEffect(() => {
    dispatch(getBooks(1)); // Fetch page 1
  }, [dispatch]);

  const featuredBooks = books.slice(0, 3); // First 3 as featured

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-yellow-100 py-12 px-4">
      <div className="w-full max-w-7xl mx-auto">
        <h1 className="text-2xl md:text-4xl font-bold mb-8 text-center text-indigo-700">
          📚 Featured Books
        </h1>

        {loading ? (
          <div className="text-center text-indigo-500">Loading featured books...</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredBooks.map((book) => (
              <BookCard key={book._id} book={book} />
            ))}
          </div>
        )}

        <div className="text-center mt-10">
          <Link
            to="/books"
            className="inline-block bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition"
          >
            View All Books
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
